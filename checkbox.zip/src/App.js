import "./App.css";
import ExpenseItem from "./components/ExpenseItem";
import Home from "./home";
function App() {
  return (
    <div className="App">
      {/* <ExpenseItem /> */}
      {/* <ExpenseItem /> */}
      <Home />
    </div>
  );
}

export default App;
